ALTER TABLE paineis ADD COLUMN crypto_currency TEXT;
ALTER TABLE paineis ADD COLUMN crypto_api_key TEXT;
